from flask import Flask, request
from flask_restful import Resource, Api

class Signin(Resource):

    def post(self):

        return {"hi" : "!!"}
